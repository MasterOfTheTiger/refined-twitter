import OptionsSync from 'webext-options-sync';

new OptionsSync().syncForm('#options-form');
